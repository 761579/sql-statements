package com.cestar.controller;

import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;

import com.cestar.dao.DaoClass;
import com.cestar.model.TaxFilers;



@ManagedBean(name="con")
@RequestScoped
public class Controllers {
	
	
	
	DaoClass obj = new DaoClass();
	int old_id=0;
	
public List<TaxFilers> display(){
		
		List<TaxFilers> taxfilers=obj.display();
		return taxfilers;
		
		
	}

public String edit(int fid) {
	
	TaxFilers taxfilers=obj.getFilerByID(fid);

	Map<String,Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
	
	sessionMap.put("tf",taxfilers);
	
	old_id = fid;
	
	return "edit";
	
}	
public String update(TaxFilers updatedFiler) {
	
	obj.update(old_id, updatedFiler);
	
	return"index";
	
	
	
}
public String delete(int fid)
{
obj.deleterec(fid);
return "index";

}
public String insert(TaxFilers filerTobeInserted)
{
	
obj.insertrecord(filerTobeInserted);
return "index";

}

	

}
