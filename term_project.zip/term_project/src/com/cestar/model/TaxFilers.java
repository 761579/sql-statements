package com.cestar.model;

import javax.faces.bean.ManagedBean;

@ManagedBean(name="filer")
public class TaxFilers {
	
	private int FilerID;
	private String Name;
	private String Contact;
	private String AnnualIncome;
	private String Expenses;
	private String TaxYear;
	public int getFilerID() {
		return FilerID;
	}
	public void setFilerID(int filerID) {
		FilerID = filerID;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getContact() {
		return Contact;
	}
	public void setContact(String contact) {
		Contact = contact;
	}
	public String getAnnualIncome() {
		return AnnualIncome;
	}
	public void setAnnualIncome(String annualIncome) {
		AnnualIncome = annualIncome;
	}
	public String getExpenses() {
		return Expenses;
	}
	public void setExpenses(String expenses) {
		Expenses = expenses;
	}
	public String getTaxYear() {
		return TaxYear;
	}
	public void setTaxYear(String taxYear) {
		TaxYear = taxYear;
	}
	@Override
	public String toString() {
		return "TaxFilers [FilerID=" + FilerID + ", Name=" + Name + ", Contact=" + Contact + ", AnnualIncome="
				+ AnnualIncome + ", Expenses=" + Expenses + ", TaxYear=" + TaxYear + "]";
	}
	public TaxFilers(int filerID, String name, String contact, String annualIncome, String expenses, String taxYear) {
		super();
		FilerID = filerID;
		Name = name;
		Contact = contact;
		AnnualIncome = annualIncome;
		Expenses = expenses;
		TaxYear = taxYear;
	}
	public TaxFilers() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	

}
