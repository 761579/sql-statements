package com.cestar.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cestar.model.TaxFilers;




public class DaoClass {
	
	

	public Connection getConnection() {

		Connection con = null;

		String url = "jdbc:mysql://localhost:3306/filersrecords";
		String user = "root";
		String pwd = "";

		try {
			Class.forName("com.mysql.jdbc.Driver");

			con = DriverManager.getConnection(url, user, pwd);

			System.out.println("Connection successful:");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;

	}
	
	
	public List<TaxFilers> display() {

		Connection con = getConnection();

		String sql = "select * from taxfilers";

		List<TaxFilers> list = new ArrayList<>();

		try {
			Statement stmt = con.createStatement();

			ResultSet rs = stmt.executeQuery(sql);
			
			
			while (rs.next()) {

				TaxFilers f = new TaxFilers(rs.getInt("FilerID"), rs.getString("Name"), rs.getString("Contact"),rs.getString("AnnualIncome"),rs.getString("Expenses"),rs.getString("TaxYear"));

				list.add(f);
			}

			System.out.println(list);

		} catch (SQLException f) {
			// TODO Auto-generated catch block
			f.printStackTrace();
		}
		return list;

	}
	
public TaxFilers getFilerByID(int curr_id){
		
		Connection con = getConnection();
		
		String sql ="select * from  taxfilers where FilerID=?";
		
		int status = 0 ;
		
		TaxFilers filer = null ;
		
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, curr_id);
			
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()){
				
				 filer = new TaxFilers(rs.getInt("FilerID"), rs.getString("Name"), rs.getString("Contact"),rs.getString("AnnualIncome"),rs.getString("Expenses"),rs.getString("TaxYear"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return filer;
		
		
		
	}

public int update(int old_id ,TaxFilers updated_filer){
	
	Connection con = getConnection();
	
	int status = 0 ;
	String sql = "update taxfilers set FilerID=? ,Name=? , Contact=?, AnnualIncome=?,Expenses=?, TaxYeay=? where FilerID=? ";
	
	try {
		PreparedStatement pstmt = con.prepareStatement(sql);
		
		pstmt.setInt(1,updated_filer.getFilerID());
		
		pstmt.setString(2,updated_filer.getName());
		pstmt.setString(3,updated_filer.getContact());
		
		
		
		pstmt.setString(4, updated_filer.getAnnualIncome());
		
		pstmt.setString(5, updated_filer.getExpenses());
		pstmt.setString(6,updated_filer.getTaxYear());
		pstmt.setInt(7,old_id);
		status = pstmt.executeUpdate();
		
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return status;

	
	
	
	}

public void deleterec(int f_id) {
	
	Connection con=getConnection();
	
	String sql= "delete from taxfilers where FilerID= ?";

	int status=0;
	
	try {
		
		PreparedStatement pstmt= con.prepareStatement(sql);
		
		pstmt.setInt(1,f_id);
		status=pstmt.executeUpdate();
		if(status>0) {
			
			
			System.out.print("Record Deleted");
		}
		else {
			
			System.out.print("Try again later");
		}
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}

public void insertrecord(TaxFilers taxfiler) {
	
	Connection con=getConnection();
	
	String sql= "insert into taxfilers values(?,?,?,?,?,?)";
	int status=0;
	try {
	
	PreparedStatement pstmt=  con.prepareStatement(sql);
	
	
	pstmt.setInt(1,taxfiler.getFilerID());
	
	pstmt.setString(2, taxfiler.getName());
	
	pstmt.setString(3, taxfiler.getContact());
	
	pstmt.setString(4,taxfiler.getAnnualIncome());
	
	pstmt.setString(5,taxfiler.getExpenses());
	pstmt.setString(5,taxfiler.getTaxYear());
	
	
	status=pstmt.executeUpdate();
	
	if(status>0) {
		
		System.out.print("Record in");
	}
	else 
	{
		
		System.out.println("try agaian");
	}
	
}
	catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}}


}
