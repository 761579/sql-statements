package com.cestar.dao;

public class daoRunner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		DaoClass obj=new DaoClass();
		obj.getFilerByID(1);
		
	}

}
