package com.cestar.dao;

public class Dao_unner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  daoclass obj=new daoclass();	


		   obj.displayAll();
				  
	}

}
