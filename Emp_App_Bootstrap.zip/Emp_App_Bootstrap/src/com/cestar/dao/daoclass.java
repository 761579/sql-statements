package com.cestar.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cestar.model.employee;

public class daoclass {
	
	public Connection getConnection()
	{
		String url ="jdbc:mysql://localhost:3306/emps";    
				String user= "root";
		String pwd ="";
		Connection con = null;
		
	
		try {
			Class.forName("com.mysql.jdbc.Driver");
			try {
				con= DriverManager.getConnection(url,user,pwd);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("connection successful");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
				
	
	 
		
		
		return	con;		
		
		
		
		
		
	}
	public List<employee> displayAll()
	{
		List<employee> emps = new ArrayList<>();
		String sql="select * from employees";
		Connection con = getConnection();
		
		try {
			Statement stmt = con.createStatement();
			
			
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next())
			{
				employee emp=new employee(rs.getInt(1),rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));
				emps.add(emp);
			}
			
			System.out.print(emps);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return emps;
		
	
	
	
	
	
	}
public void insertrecord(employee emp) {
		
		Connection con=getConnection();
		
		String sql= "insert into employees values(?,?,?,?,?)";
		int status=0;
		try {
		
		PreparedStatement pstmt=  con.prepareStatement(sql);
		
		
		pstmt.setInt(1,emp.getId());
		
		pstmt.setString(2, emp.getName());
		
		pstmt.setString(3, emp.getCity());
		
		pstmt.setString(4,emp.getDepartment());
		
		pstmt.setString(5,emp.getEmail());
		
		
		status=pstmt.executeUpdate();
		
		if(status>0) {
			
			System.out.print("Record in");
		}
		else 
		{
			
			System.out.println("try agaian");
		}
		
	}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}}
public void deleterec(int e_id) {
	
	Connection con=getConnection();
	
	String sql= "delete from employees where id= ?";

	int status=0;
	
	try {
		
		PreparedStatement pstmt= con.prepareStatement(sql);
		
		pstmt.setInt(1,e_id);
		status=pstmt.executeUpdate();
		if(status>0) {
			
			
			System.out.print("Record Deelete");
		}
		else {
			
			System.out.print("Try again later");
		}
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}

}
