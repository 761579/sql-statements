package com.cestar.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cestar.dao.daoclass;
import com.cestar.model.employee;

/**
 * Servlet implementation class Controller
 */
@WebServlet("/")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Controller() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out= response.getWriter();
		String url =request.getServletPath();
		switch(url) {
		case "/display":
		
		
		{   display(request, response);
			out.print(" i am from diaplay servlet");
			break;
			
		}
		case "/insert":
		{
			insert(request,response);
			break;
			
		}


		case "/delete":
		{
			delete(request,response);
			break;
		}
		default:
		{
			out.print("sorry , page is unavailable");
		}
		}
	}

private void delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int e_id=Integer.parseInt(request.getParameter("e_id"));
		
		daoclass obj=new daoclass();
		obj.deleterec(e_id);
		
		display(request,response);
		
		
		// TODO Auto-generated method stub
		
	}

	protected void insert(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		int id=Integer.parseInt(request.getParameter("e_id"));
		
		String name=request.getParameter("e_name");
		
		
		String city=request.getParameter("e_city");
		
		String dept=request.getParameter("e_dept");
		
		String email=request.getParameter("e_email");
		
		employee emp=new employee(id,name,city,dept,email);
		
		
	daoclass obj=new daoclass();
			
			obj.insertrecord(emp);
	display(request, response);
	
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	
	protected void display(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		daoclass obj= new daoclass();
		List<employee> emps= obj.displayAll();
		 
		HttpSession session= request.getSession();
		
		session.setAttribute("emps", emps);
		
		response.sendRedirect("display.jsp");
		
	}
}
