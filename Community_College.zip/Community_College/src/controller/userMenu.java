package controller;

import java.util.Scanner;

import student_dao.DaoClass;

public class userMenu {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
	System.out.println("Please choose number 1 to 5");
	
	System.out.println("Enter 1 to display all data");
	System.out.println("Enter 2 to add one more student ");
	System.out.println("Enter 3 to add more students ");
	System.out.println("Enter 4 to delete students");
	System.out.println("Enter 5 to update data ");
	int userchoise=sc.nextInt();
	DaoClass dc=new DaoClass();
	
	switch(userchoise)
	{
	case 1:
	{
		dc.displayData();
		break;
	}
	case 2:
	{
		dc.insertstudent();
		break;
	}
	case 3:
	{
		dc.insertMoreStudents();
		break;
	}
	case 4:
	{
		dc.deleteBook();
		break;
	}
	case 5:
	{
		dc.updateBook();
		break;
	}
	default :
	{System.out.println("Please enter a number between 1 to 5 only");}
	}
	}

}
