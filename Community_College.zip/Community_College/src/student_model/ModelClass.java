/**
 * 
 */
package student_model;

/**
 * @author anjal
 *
 */
public class ModelClass {

	private  int studentID;
	private String name;
	private int contact;
	private String course_name;
	private int semester;
	private int attendance;
	private String final_grade;
	public int getStudentID() {
		return studentID;
	}
	public void setStudentID(int studentID) {
		this.studentID = studentID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getContact() {
		return contact;
	}
	public void setContact(int contact) {
		this.contact = contact;
	}
	public String getCourse_name() {
		return course_name;
	}
	public void setCourse_name(String course_name) {
		this.course_name = course_name;
	}
	public int getSemester() {
		return semester;
	}
	public void setSemester(int semester) {
		this.semester = semester;
	}
	public int getAttendance() {
		return attendance;
	}
	public void setAttendance(int attendance) {
		this.attendance = attendance;
	}
	public String getFinal_grade() {
		return final_grade;
	}
	public void setFinal_grade(String final_grade) {
		this.final_grade = final_grade;
	}
	
	public ModelClass(int studentID, String name, int contact, String course_name, int semester, int attendance, String final_grade ) {
		super();
		this.studentID = studentID;                
		this.name = name;
		this.contact = contact;
		this.course_name = course_name;
		this.semester = semester;
		this.attendance= attendance;
		this.final_grade = final_grade;
		
		
	}
	public ModelClass() {
		super();	
		// TODO Auto-generated constructor stub
	}
	public String toString() {
		return "ModelClass[Student ID = " + studentID + ", Name = " + name + ", Contact = " + contact +", Course Name  = "+course_name +", Semester = "+semester+", Attendance = "+attendance+",Final Grade  = "+final_grade +"]";
			}
			
	

}
