/**
 * 
 */
package student_dao;

/**
 * @author anjal
 *
 */
public class RunnerClass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

DaoClass dc=new DaoClass();
dc.getConnection();

	}

}
