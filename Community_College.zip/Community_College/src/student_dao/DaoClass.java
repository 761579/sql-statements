/**
 * 
 */
package student_dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import student_model.ModelClass;

/**
 * @author anjal
 *
 */
public class DaoClass {

	/**
	 * @param args
	 */
	public Connection getConnection() {

		// Register the driver Class

		Connection con = null;

		try {
			Class.forName("com.mysql.jdbc.Driver");

			String url = "jdbc:mysql://localhost:3306/semesterrecords";

			String user = "root";

			String pwd = "";

			con = DriverManager.getConnection(url, user, pwd);

			System.out.println("Connection Successfull:");

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;

	}
	
	public void displayData(){
		
		Connection con = getConnection();
		
		List<ModelClass>  mc = new ArrayList<>();
		
		String sql = "select * from students" ;
		
		try {
			
			Statement stmt = con.createStatement();
			
			ResultSet  rs = stmt.executeQuery(sql);
		
		    while(rs.next()){
		    	
		    	ModelClass  b1 = new ModelClass(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getString(4),rs.getInt(5),rs.getInt(6),rs.getString(7));
		    	
		    	mc.add(b1);
		    	
		    }
		
		
		    
		    for(int i=1;i<mc.size();i++){
		    	
		    	
		    	System.out.println("Student ID= "+mc.get(i).getStudentID()+"  Name= "+mc.get(i).getName()+"  contact= "+mc.get(i).getContact()+"Course= "+mc.get(i).getCourse_name()+"Semester = "+mc.get(i).getSemester()+"Attendance= "+mc.get(i).getAttendance()+"Final grade= "+mc.get(i).getFinal_grade());
		    }
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

}
	

	


public void insertstudent() {

	Scanner sc = new Scanner(System.in);

	System.out.println("Please enter an ID for Student:");

	int id = sc.nextInt();

	sc.nextLine();

	System.out.println("Please enter the name of the Student:");

	String name = sc.nextLine();

	System.out.println("Please enter the Contact:");

	int contact = sc.nextInt();
	sc.nextLine();

	System.out.println("Please enter the Course name:");

	String Course_name = sc.nextLine();
	
	System.out.println("Please enter the semester:");
	 int Sem = sc.nextInt();
	 sc.nextLine();
	   
	System.out.println("Please enter the Attendance:");

	int attendance = sc.nextInt();
	sc.nextLine();
	
	System.out.println("Please enter the Grade:");

	String Final_grade = sc.nextLine();

	String sql = "insert into students(studentID,name,contact,course_name,semester,attendance,final_grade) values(?,?,?,?,?,?,?)";

	Connection con = getConnection();

	try {
		PreparedStatement pstmt = con.prepareStatement(sql);

		pstmt.setInt(1, id);

		pstmt.setString(2, name);

		pstmt.setInt(3, contact);
		pstmt.setString(4, Course_name);
		pstmt.setInt(5, Sem);
		
		pstmt.setInt(6, attendance);
		pstmt.setString(7, Final_grade);

		int status = pstmt.executeUpdate();

		if (status > 0) {
			System.out.println("Record Inserted Successfully");
		} else {

			System.out.println("Please Try again:");
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

}

public void insertMoreStudents() {

	Scanner sc = new Scanner(System.in);

	System.out.println("Please enter how many stududents you want to enter:");

	int number = sc.nextInt();

	for (int i = 1; i <= number; i++) {

		insertstudent();
		if (i == number) {

			System.out.println("You enterd  " + number + " books in total:");
		}

	}

}

public void deleteBook() {

	int ch = 10;

	Scanner sc = new Scanner(System.in);

	while (ch != 0) {

		System.out.println("Please enter 1 to delete Record or 0 to exit");

		ch = sc.nextInt();
		 sc.nextLine();

		if (ch == 1) {

			String sql = "delete from students where studentID=?";

			System.out.println("Please enter the id of the record to be deleted:");

			int id = sc.nextInt();
			 sc.nextLine();
			Connection con = getConnection();

			try {
				PreparedStatement pstmt = con.prepareStatement(sql);

				pstmt.setInt(1, id);

				int status = pstmt.executeUpdate();

				if (status > 0) {

					System.out.println("Record deleted successfully:");

					displayData();

				}

				else {

					System.out.println("Please Try agaian:");
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		else if (ch == 0) {

			System.out.println("Thanks for using Application Good Bye:");
			System.exit(0);
		}

		else {

			System.out.println("Invalid Number please enter 0 or 1:");
		}

	}

}

public void updateBook(){
	
	Scanner sc = new Scanner(System.in);
	
	System.out.println("Please enter an ID of Student to be updated:");

	int present_id = sc.nextInt();

	sc.nextLine();
	System.out.println("Please enter an ID for Student:");

	int id = sc.nextInt();

	sc.nextLine();

	System.out.println("Please enter the name of the Student:");

	String name = sc.nextLine();

	System.out.println("Please enter the Contact:");

	int contact = sc.nextInt();
	sc.nextLine();

	System.out.println("Please enter the Course name:");

	String Course_name = sc.nextLine();
	
	System.out.println("Please enter the semester:");
	 int Sem = sc.nextInt();
	 sc.nextLine();
	   
	System.out.println("Please enter the Attendance:");

	int attendance = sc.nextInt();
	sc.nextLine();
	
	System.out.println("Please enter the Grade:");

	String Final_grade = sc.nextLine();
	String sql = "update students set studentID=? ,name=? ,contact=?,course_name=?, semester=?, attendance=?, final_grade=? where studentID=?";
	
	Connection con = getConnection();
	
	try {
		PreparedStatement pstmt = con.prepareStatement(sql);
	
		pstmt.setInt(1, id);

		pstmt.setString(2, name);

		pstmt.setInt(3, contact);
		pstmt.setInt(5, Sem);
		pstmt.setString(4, Course_name);
		pstmt.setInt(6, attendance);
		pstmt.setString(7, Final_grade);
		pstmt.setInt(8, present_id);
	    int status = pstmt.executeUpdate();
	    
	    if(status>0){
	    	
	    	System.out.println("Record Updated Successfully:");
	    }
	    else {
	    	
	    	System.out.println("Try again later:");
	    }
	
	
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	
	
	
	
}

}