package com.cestar.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cestar.dao.daoClass;

import com.cestar.model.liberaryRecords;

/**
 * Servlet implementation class Controller
 */
@WebServlet("/")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Controller() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out= response.getWriter();
		String url =request.getServletPath();
		switch(url) {
		case "/display":
		
		
		{   display(request, response);
			out.print(" i am from diaplay servlet");
			break;
			
		}
		case "/insert":
		{
			insert(request,response);
			break;
			
		}
		case "/update":
		{
			update(request,response);
			break;
			
		}
 

		case "/delete":
		{
			delete(request,response);
			break;
		}
		default:
		{
			out.print("sorry , page is unavailable");
		}
		}
	}
	private void display(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		daoClass obj= new daoClass();
		List<liberaryRecords> liberaryrecords= obj.displayAll();
		 
		HttpSession session= request.getSession();
		
		session.setAttribute("liberaryrecords", liberaryrecords);
		
		response.sendRedirect("display.jsp");
	}

	private void update(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
	}

	private void delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
    int b_id=Integer.parseInt(request.getParameter("b_id"));
		
		daoClass obj=new daoClass();
		obj.deleterec(b_id);
		
		display(request,response);
	}

	private void insert(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException {
		// TODO Auto-generated method stub
int    id=Integer.parseInt(request.getParameter("u_id"));
		
		String name=request.getParameter("u_name");
		
		
		String contact=request.getParameter("contact");
		
		String book_issued=request.getParameter("Book_Issued");
		
		String date_issued=request.getParameter("Date_Issued");
		String date_retured=request.getParameter("Date_Issued");
		
		liberaryRecords lib=new liberaryRecords(id,name,contact,book_issued,date_issued, date_retured);;
		
		
	daoClass obj=new daoClass();
			
			obj.insertrecord(lib);
	display(request, response);
	}

	
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
