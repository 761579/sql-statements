package com.cestar.model;

public class liberaryRecords {
private  int User_Id;
private String  Name;
private String Contact;
private String Book_Issued;
private String Date_Issued;
private String Date_Returned;
public int getUser_Id() {
	return User_Id;
}
public void setUser_Id(int user_Id) {
	User_Id = user_Id;
}
public String getName() {
	return Name;
}
public void setName(String name) {
	Name = name;
}
public String getContact() {
	return Contact;
}
public void setContact(String contact) {
	Contact = contact;
}
public String getBook_Issued() {
	return Book_Issued;
}
public void setBook_Issued(String book_Issued) {
	Book_Issued = book_Issued;
}
public String getDate_Issued() {
	return Date_Issued;
}
public void setDate_Issued(String date_Issued) {
	Date_Issued = date_Issued;
}
public String getDate_Returned() {
	return Date_Returned;
}
public void setDate_Returned(String date_Returned) {
	Date_Returned = date_Returned;
}
public liberaryRecords(int user_Id, String name, String contact, String book_Issued, String date_Issued,
		String date_Returned) {
	super();
	User_Id = user_Id;
	Name = name;
	Contact = contact;
	Book_Issued = book_Issued;
	Date_Issued = date_Issued;
	Date_Returned = date_Returned;
}
@Override
public String toString() {
	return "liberaryRecords [User_Id=" + User_Id + ", Name=" + Name + ", Contact=" + Contact + ", Book_Issued="
			+ Book_Issued + ", Date_Issued=" + Date_Issued + ", Date_Returned=" + Date_Returned + "]";
}
public liberaryRecords() {
	super();
	// TODO Auto-generated constructor stub
}

	
	


}
