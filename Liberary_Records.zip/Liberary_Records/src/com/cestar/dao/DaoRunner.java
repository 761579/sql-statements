/**
 * 
 */
package com.cestar.dao;

/**
 * @author anjal
 *
 */
public class DaoRunner {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
  daoClass obj = new daoClass();
  obj.updateBook();
	}

}
