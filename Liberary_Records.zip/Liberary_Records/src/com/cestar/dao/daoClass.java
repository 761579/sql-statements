package com.cestar.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cestar.model.liberaryRecords;

public class daoClass {

	public Connection getConnection()
	{
		String url ="jdbc:mysql://localhost:3306/liberaryrecords";    
				String user= "root";
		String pwd ="";
		Connection con = null;
		
	
		try {
			Class.forName("com.mysql.jdbc.Driver");
			try {
				con= DriverManager.getConnection(url,user,pwd);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("connection successful");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
				
	
	 
		
		
		return	con;		
		
		
		
		
		
	}
	public List<liberaryRecords> displayAll()
	{
		List<liberaryRecords> record = new ArrayList<>();
		String sql="select * from liberary_user";
		Connection con = getConnection();
		
		try {
			Statement stmt = con.createStatement();
			
			
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next())
			{
				liberaryRecords data=new liberaryRecords(rs.getInt(1),rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),rs.getString(6));
				record.add(data);
			}
			
			System.out.print(record);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return record;
		
	
	
	
	
	
	}
public void insertrecord( liberaryRecords librec) {
		
		Connection con=getConnection();
		
		String sql= "insert into liberary_user values(?,?,?,?,?,?)";
		int status=0;
		try {
		
		PreparedStatement pstmt=  con.prepareStatement(sql);
		
		
		pstmt.setInt(1,librec.getUser_Id());
		
		pstmt.setString(2, librec.getName());
		
		pstmt.setString(3,librec.getContact());
		
		pstmt.setString(4,librec.getBook_Issued());
		
		pstmt.setString(5,librec.getDate_Issued());
		pstmt.setString(6,librec.getDate_Returned());
		
		
		status=pstmt.executeUpdate();
		
		if(status>0) {
			
			System.out.print("Record inserted");
		}
		else 
		{
			
			System.out.println("try again");
		}
		
	}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}}
public void deleterec(int b_id) {
	
	Connection con=getConnection();
	
	String sql= "delete from liberary_user where User_Id=?";

	int status=0;
	
	try {
		
		PreparedStatement pstmt= con.prepareStatement(sql);
		
		pstmt.setInt(1,b_id);
		status=pstmt.executeUpdate();
		if(status>0) {
			
			
			System.out.print("Record Deelete");
		}
		else {
			
			System.out.print("Try again later");
		}
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}

public void updateBook(){
	
	Scanner sc = new Scanner(System.in);
	
	System.out.println("Please enter an ID of User to be updated:");

	int present_id = sc.nextInt();

	sc.nextLine();
	System.out.println("Please enter new ID for User:");

	int id = sc.nextInt();

	sc.nextLine();

	System.out.println("Please enter the name of the User:");

	String name = sc.nextLine();

	System.out.println("Please enter the Contact:");

	String contact = sc.nextLine();
	

	System.out.println("Please enter the Book name:");

	String book_name = sc.nextLine();
	
	System.out.println("Please enter the date issued:");
	 String date_issued= sc.nextLine();
	
	   
	System.out.println("Please enter the date Returned:");

	 String date_returned= sc.nextLine();

	

	String sql = "update  liberary_user set User_Id=? , Name=? ,Contact=?, Book_Issued=?, Date_Issued=?, Date_Returned=? where User_Id=?";
	
	Connection con = getConnection();
	
	try {
		PreparedStatement pstmt = con.prepareStatement(sql);
	
		pstmt.setInt(1, id);

		pstmt.setString(2, name);

		pstmt.setString(3, contact);
		
		pstmt.setString(4, book_name);
		pstmt.setString(5, date_issued);
		pstmt.setString(6,date_returned);
		pstmt.setInt(7, present_id);
	    int status = pstmt.executeUpdate();
	    
	    if(status>0){
	    	
	    	System.out.println("Record Updated Successfully:");
	    }
	    else {
	    	
	    	System.out.println("Try again later:");
	    }
	
	
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	
	
	
	
}
}

