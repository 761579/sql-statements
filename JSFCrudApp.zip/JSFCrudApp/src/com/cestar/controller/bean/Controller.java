package com.cestar.controller.bean;

import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import com.cestar.dao.EmpDao;
import com.cestar.model.bean.Employee;
import java.util.Map;

@ManagedBean(name="con")
@RequestScoped


public class Controller {
	
	

	EmpDao obj= new EmpDao();
	
	int old_id=0;

	


	
	public List<Employee> display(){
		
		List<Employee> emps=obj.display();
		return emps;
		
		
	}
	
	
	
public String edit(int eid) {
	
	Employee emp=obj.getEmployeeByID(eid);

	Map<String,Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
	
	sessionMap.put("em", emp);
	
	old_id = eid;
	
	return "edit";
	
}	


public String update(Employee updated_emp) {
	
	obj.update(old_id, updated_emp);
	
	return"index";
	
	
	
}

public String delete(int eid)
{
obj.deleterec(eid);
return "index";

}
public String insert(Employee empTobeInserted)
{
	
obj.insertrecord(empTobeInserted);
return "index";

}
}
