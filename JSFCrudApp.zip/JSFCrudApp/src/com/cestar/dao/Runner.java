package com.cestar.dao;

public class Runner {

	public static void main(String[] args) {
	
		
		EmpDao obj = new EmpDao();
		obj.getEmployeeByID(4);
		// TODO Auto-generated method stub

	}
	
	
	

}
