package com.cestar.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import com.cestar.model.bean.Employee;

public class EmpDao {

	public Connection getConnection() {

		Connection con = null;

		String url = "jdbc:mysql://localhost:3306/emps";
		String user = "root";
		String pwd = "";

		try {
			Class.forName("com.mysql.jdbc.Driver");

			con = DriverManager.getConnection(url, user, pwd);

			System.out.println("Connection successful:");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;

	}

	public List<Employee> display() {

		Connection con = getConnection();

		String sql = "select * from employees";

		List<Employee> list = new ArrayList<>();

		try {
			Statement stmt = con.createStatement();

			ResultSet rs = stmt.executeQuery(sql);
			
			
			while (rs.next()) {

				Employee e = new Employee(rs.getInt("id"), rs.getString("name"), rs.getString("city"),rs.getString("d11partment"),rs.getString("email"));

				list.add(e);
			}

			System.out.println(list);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;

	}

	
	public Employee getEmployeeByID(int curr_id){
		
		Connection con = getConnection();
		
		String sql ="select * from employees where id=?";
		
		int status = 0 ;
		
		Employee emp = null ;
		
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, curr_id);
			
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()){
				
				 emp = new Employee(rs.getInt("id"), rs.getString("name"), rs.getString("city"),rs.getString("department"),rs.getString("email"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return emp;
		
		
		
	}
	
	public int update(int old_id ,Employee e_updated){
		
		Connection con = getConnection();
		
		int status = 0 ;
		String sql = "update employees set id=? ,name=? , city=?, department=?, email=? where id=? ";
		
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1,e_updated.getId());
			
			pstmt.setString(2,e_updated.getName());
			pstmt.setString(3,e_updated.getCity());
			
			
			
			pstmt.setString(4, e_updated.getDepartment());
			
			pstmt.setString(5, e_updated.getEmail());
			pstmt.setInt(6,old_id);
			status = pstmt.executeUpdate();
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;
	
		
		
		
		}
	
	public void deleterec(int e_id) {
		
		Connection con=getConnection();
		
		String sql= "delete from employees where id= ?";

		int status=0;
		
		try {
			
			PreparedStatement pstmt= con.prepareStatement(sql);
			
			pstmt.setInt(1,e_id);
			status=pstmt.executeUpdate();
			if(status>0) {
				
				
				System.out.print("Record Deelete");
			}
			else {
				
				System.out.print("Try again later");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
public void insertrecord(Employee emp) {
		
		Connection con=getConnection();
		
		String sql= "insert into employees values(?,?,?,?,?)";
		int status=0;
		try {
		
		PreparedStatement pstmt=  con.prepareStatement(sql);
		
		
		pstmt.setInt(1,emp.getId());
		
		pstmt.setString(2, emp.getName());
		
		pstmt.setString(3, emp.getCity());
		
		pstmt.setString(4,emp.getDepartment());
		
		pstmt.setString(5,emp.getEmail());
		
		
		status=pstmt.executeUpdate();
		
		if(status>0) {
			
			System.out.print("Record in");
		}
		else 
		{
			
			System.out.println("try agaian");
		}
		
	}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}}
	
	}



	

